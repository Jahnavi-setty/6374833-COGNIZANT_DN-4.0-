public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public void close() {
        // simulate resource cleanup
        System.out.println("Resources cleaned up.");
    }
}