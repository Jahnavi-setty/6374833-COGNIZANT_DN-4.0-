package com.example;

public class Dummy {
    // Empty class – just to maintain main source folder
}