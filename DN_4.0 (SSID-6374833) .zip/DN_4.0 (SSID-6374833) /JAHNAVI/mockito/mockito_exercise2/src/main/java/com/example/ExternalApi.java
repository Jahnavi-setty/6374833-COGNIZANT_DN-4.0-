package com.example;

public interface ExternalApi {
    void getData();
}
